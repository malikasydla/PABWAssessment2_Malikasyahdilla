<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar Akun Asprak</title>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
</head>

<body>
    <h1>Laporan Pembayaran</h1>

    <table border="1" cellspacing="0" id="paymentTable">
        <thead>
            <tr>
                <th>Nama</th>
                <th>Kelas</th>
                <th>Tagihan SPP</th>
                <th>Tanggal Pembayaran</th>
                <th>Sisa Pembayaran</th>
                <th>Status Pembayaran</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
        </tbody>
    </table>

    <script>
        $(document).ready(function() {
            function fetchAndDisplayPayments() {
                $.getJSON("payment_data.json", function(data) {
                    $("#paymentTable tbody").empty();

                    $.each(data, function(index, payment) {
                        var newRow = $("<tr>");
                        newRow.append("<td>" + payment.nama + "</td>");
                        newRow.append("<td>" + payment.kelas + "</td>");
                        newRow.append("<td>" + payment.tagihan_spp + "</td>");
                        newRow.append("<td>" + payment.tanggal_pembayaran + "</td>");
                        newRow.append("<td>" + payment.sisa_pembayaran + "</td>");
                        newRow.append("<td>" + payment.status_pembayaran + "</td>");
                        newRow.append("<td><a href='edit.php?nama=" + payment.nama + "'>Edit</a> <a href='menghapus_data.php?id=" + payment.id + "'>Hapus</a></td>");
                        $("#paymentTable tbody").append(newRow);
                    });
                });
            }
            fetchAndDisplayPayments();
        });
    </script>
</body>

</html>
