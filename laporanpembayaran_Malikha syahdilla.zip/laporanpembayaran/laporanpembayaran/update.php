<?php
if (isset($_POST['nama'])) {
    $namaToUpdate = $_POST['nama'];

    $jsonString = file_get_contents('payment_data.json');
    $data = json_decode($jsonString, true);

    foreach ($data as $key => $payment) {
        if ($payment['nama'] == $namaToUpdate) {
            $data[$key]['kelas'] = $_POST['kelas'];
            $data[$key]['tagihan_spp'] = $_POST['tagihan_spp'];
            $data[$key]['tanggal_pembayaran'] = $_POST['tanggal_pembayaran'];
            $data[$key]['sisa_pembayaran'] = $_POST['sisa_pembayaran'];
            $data[$key]['status_pembayaran'] = $_POST['status_pembayaran'];
            break;
        }
    }

    $newJsonString = json_encode($data, JSON_PRETTY_PRINT);
    file_put_contents('payment_data.json', $newJsonString);

    header('Location: index.php');
}
?>
