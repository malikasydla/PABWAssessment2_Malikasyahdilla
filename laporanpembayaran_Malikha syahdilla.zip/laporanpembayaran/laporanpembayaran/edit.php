<?php
if (isset($_GET['nama'])) {
    $namaToEdit = $_GET['nama'];

    $jsonString = file_get_contents('payment_data.json');
    $data = json_decode($jsonString, true);

    $projectToEdit = null;
    foreach ($data as $key => $project) {
        if (isset($project['nama']) && $project['nama'] == $namaToEdit) {
            $projectToEdit = $project;
            break;
        }
    }

    if (isset($projectToEdit['nama']) && isset($projectToEdit['kelas']) && isset($projectToEdit['tagihan_spp']) && isset($projectToEdit['tanggal_pembayaran']) && isset($projectToEdit['sisa_pembayaran']) && isset($projectToEdit['status_pembayaran'])) {
?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Edit</title>
    </head>
    <body>
        <h1>Edit Data</h1>
        <form action="update.php" method="POST">
    <input type="hidden" name="nama" value="<?php echo $projectToEdit['nama']; ?>">
    <label for="kelas">Kelas:</label>
    <input type="text" id="kelas" name="kelas" value="<?php echo $projectToEdit['kelas']; ?>"><br>

    <label for="tagihan_spp">Tagihan SPP:</label>
    <input type="text" id="tagihan_spp" name="tagihan_spp" value="<?php echo $projectToEdit['tagihan_spp']; ?>"><br>

    <label for="tanggal_pembayaran">Tanggal:</label>
    <input type="text" id="tanggal_pembayaran" name="tanggal_pembayaran" value="<?php echo $projectToEdit['tanggal_pembayaran']; ?>"><br>

    <label for="sisa_pembayaran">Sisa Pembayaran:</label>
    <input type="text" id="sisa_pembayaran" name="sisa_pembayaran" value="<?php echo $projectToEdit['sisa_pembayaran']; ?>"><br>

    <label for="status_pembayaran">Status Pembayaran:</label>
    <input type="text" id="status_pembayaran" name="status_pembayaran" value="<?php echo $projectToEdit['status_pembayaran']; ?>"><br>

    <button type="submit">Update</button>
</form>
    </body>
    </html>
<?php
    } else {
        echo "Data tidak lengkap atau tidak ditemukan.";
    }
}
?>
